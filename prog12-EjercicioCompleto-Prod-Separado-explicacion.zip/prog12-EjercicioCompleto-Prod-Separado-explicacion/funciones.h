#ifndef FUNCIONES_H
#define FUNCIONES_H

    unsigned int int_aleatorio(unsigned int min,unsigned int max);

#endif